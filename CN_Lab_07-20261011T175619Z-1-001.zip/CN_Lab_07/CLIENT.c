#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 30905
#define BUFFER_SIZE 1024

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        printf("Usage: %s <server_ip> <roll>\n", argv[0]);
        return 1;
    }

    int sockfd;
    char input[BUFFER_SIZE];
    char message[BUFFER_SIZE];
    char buffer[BUFFER_SIZE];

    struct sockaddr_in server_addr;
    socklen_t addr_len = sizeof(server_addr);

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    if (sockfd < 0)
    {
        perror("Socket creation failed");
        return 1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);

    if (inet_pton(AF_INET, argv[1], &server_addr.sin_addr) <= 0)
    {
        perror("Invalid IP address");
        close(sockfd);
        return 1;
    }

    while (1)
    {
        printf("Enter text (or EXIT): ");

        if (fgets(input, sizeof(input), stdin) == NULL)
            break;

        input[strcspn(input, "\n")] = '\0';

        sprintf(message, "%s#%s", argv[2], input);

        sendto(sockfd,
               message,
               strlen(message),
               0,
               (struct sockaddr *)&server_addr,
               addr_len);

        int n = recvfrom(sockfd,
                         buffer,
                         BUFFER_SIZE - 1,
                         0,
                         NULL,
                         NULL);

        if (n < 0)
        {
            perror("recvfrom failed");
            continue;
        }

        buffer[n] = '\0';

        printf("Server Response: %s\n", buffer);

        if (strcmp(input, "EXIT") == 0)
            break;
    }

    close(sockfd);
    return 0;
}
